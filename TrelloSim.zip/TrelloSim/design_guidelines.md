# Design Guidelines - Trello Clone Application

## Design Approach

**Reference-Based Approach: Trello-Inspired Design**

This project draws primary inspiration from Trello's proven Kanban interface, emphasizing clarity, color, and collaborative workflows. We'll adapt Trello's visual patterns while maintaining modern web standards and the technical requirements specified in your documentation.

**Key Design Principles:**
- Visual clarity over decoration
- Color-coded organization
- Immediate feedback for all interactions
- Collaborative transparency
- Progressive disclosure of complexity

---

## Typography

**Font Family:**
- Primary: 'Inter' or 'SF Pro Display' from Google Fonts
- Fallback: system-ui, -apple-system, sans-serif

**Type Scale:**
- Board Title: 1.5rem (24px), font-weight 700
- List Header: 1rem (16px), font-weight 600
- Card Title: 0.875rem (14px), font-weight 500
- Body Text: 0.875rem (14px), font-weight 400
- Metadata/Badges: 0.75rem (12px), font-weight 500
- Buttons: 0.875rem (14px), font-weight 600

**Line Height:**
- Headlines: 1.2
- Body: 1.5
- Compact (badges, labels): 1.3

---

## Layout System

**Spacing Units (Tailwind):**
Primary spacing scale: 2, 3, 4, 6, 8, 12, 16, 24 units

**Board Layout:**
- Board container: Full viewport with horizontal scroll
- List width: 272px fixed
- List spacing: gap-3 (12px horizontal)
- Board padding: p-4 top/bottom, px-6 left/right

**List Layout:**
- Header: p-3
- Card spacing: gap-2 (8px vertical)
- Content padding: px-3 pb-3

**Card Layout:**
- Padding: p-3
- Border radius: rounded-lg (8px)
- Min height: 32px
- Element spacing: gap-2 internal

**Modal Layout:**
- Max width: 768px
- Two-column split: 65% content / 35% sidebar
- Content padding: p-6
- Sidebar padding: p-4

---

## Component Library

### Navigation/Header
- Fixed top bar: h-12, dark background
- Logo/workspace selector left
- Search center
- User menu right
- All items vertically centered with px-4

### Board Component
- Horizontal scrolling container
- Lists displayed in row with gap-3
- Smooth scroll behavior
- Auto-scroll during drag near edges
- Background gradient or solid subtle color

### List Component
- White background, rounded-lg
- Shadow: shadow-sm, elevated on hover (shadow-md)
- Header with drag handle (6 dots icon)
- Title with inline edit on click
- "Add card" button at bottom, subtle, text-left
- Max height with scroll if many cards

### Card Component
**Card Structure:**
- White background, rounded-lg
- Border: 1px solid transparent (colored on hover)
- Shadow: shadow-sm
- Hover state: shadow-md, slight translate-y lift
- Cover image: Full-width at top, rounded-t-lg, h-32 if present

**Card Content Hierarchy:**
- Labels row: gap-1, max 4 visible, pill-shaped, h-2 minimal
- Title: mt-2, font-medium, line-clamp-3
- Badges row: mt-3, gap-3, flex-wrap
  - Members: Overlapping avatars, max 4 shown
  - Due date: Icon + text, color-coded (red if overdue)
  - Checklist: Progress icon + "3/5"
  - Attachments: Icon + count
  - Comments: Icon + count

**Badge Styling:**
- Small icons: w-4 h-4
- Text: text-xs
- Gap between icon and text: gap-1
- Subtle gray color, accented when active/overdue

### Card Modal
**Layout:**
- Overlay: backdrop-blur-sm, bg-black/50
- Modal: bg-white, rounded-xl, shadow-2xl
- Header: Title with inline edit, close button top-right
- Content area scrollable
- Sidebar fixed width: 192px

**Content Sections:**
- Description editor: Border on focus, min-h-24
- Checklist: Checkbox + text rows, strikethrough completed
- Attachments: Grid layout, thumbnail previews
- Activity: Timeline style, avatar left, content right
- Comment input: Sticky at bottom, elevated shadow

**Sidebar Actions:**
- Grouped sections with labels
- Icon + text buttons
- Hover: bg-gray-100
- Active: bg-blue-50

### Labels
- Pill shape: rounded-full
- Height: h-2 (minimal on card), h-6 (in modal/picker)
- Width: On card 40px, in picker full with text
- Vibrant colors: green, yellow, orange, red, purple, blue, teal, pink, black
- Hover: Slightly darker shade

### Buttons
**Primary (Create, Save):**
- bg-blue-600, text-white
- Hover: bg-blue-700
- Padding: px-4 py-2
- rounded-md

**Secondary (Cancel):**
- bg-gray-100, text-gray-700
- Hover: bg-gray-200

**Icon Buttons:**
- p-2, rounded-md
- Hover: bg-gray-100
- Icon size: w-5 h-5

### Forms
- Input fields: border-gray-300, rounded-md, p-2
- Focus: ring-2 ring-blue-500, border-blue-500
- Labels: text-sm, font-medium, mb-1
- Error states: border-red-500, text-red-600

### Drag & Drop States
- Dragging card: opacity-50, rotate-3
- Drop zone highlight: border-2 border-dashed border-blue-400, bg-blue-50
- Placeholder: h-8, border-2 border-dashed border-gray-300, rounded-md

---

## Responsive Breakpoints

**Mobile (<768px):**
- Lists stack vertically, full width
- Card modal full-screen
- Sidebar becomes bottom sheet
- Simplified navigation (hamburger)

**Tablet (768px-1024px):**
- 2-3 lists visible, horizontal scroll
- Card modal centered, max-w-2xl

**Desktop (>1024px):**
- Full board layout
- 4+ lists comfortably visible
- All hover interactions active

---

## Animations

**Use Sparingly - Performance First**

**Allowed Animations:**
- Card drag: Transform translate, 200ms ease
- Card hover: Shadow transition, 150ms
- Modal open/close: Fade + scale, 200ms
- List add: Slide in from right, 300ms
- Toast notifications: Slide in from top, 250ms

**No Animations:**
- Avoid animated backgrounds
- No continuous animations
- No auto-playing elements
- Disable all animations in drag mode for performance

---

## Images

**Hero Section:** None - This is a productivity app, dive straight into boards

**Image Usage:**
- Card cover images: User-uploaded, 16:9 aspect, object-cover
- User avatars: Circular, 24px-32px standard, 48px in modal
- Workspace icons: 40px, rounded-lg
- Empty states: Simple illustrations, max 200px, centered

**Image Placement:**
- Card covers: Top of card, full-width
- Attachments: Grid in modal, thumbnail size 120px
- User profile: Top-right navigation

---

## Accessibility

- Focus visible: ring-2 ring-blue-500 on all interactive elements
- Skip to main content link
- ARIA labels on all icon buttons
- Keyboard navigation: Tab through cards, Enter to open, Esc to close
- Screen reader announcements for drag-drop actions
- Color contrast minimum WCAG AA (4.5:1 for text)