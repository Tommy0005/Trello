import { sql, relations } from "drizzle-orm";
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  real,
  boolean,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const roleEnum = pgEnum("role", ["admin", "member", "viewer"]);

// Session storage table (mandatory for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);

// User storage table (mandatory for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const usersRelations = relations(users, ({ many }) => ({
  workspaceMembers: many(workspaceMembers),
  boardMembers: many(boardMembers),
  cardMembers: many(cardMembers),
  comments: many(comments),
  activities: many(activities),
}));

// Workspaces
export const workspaces = pgTable("workspaces", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const workspacesRelations = relations(workspaces, ({ many }) => ({
  members: many(workspaceMembers),
  boards: many(boards),
}));

// Workspace Members (with roles)
export const workspaceMembers = pgTable(
  "workspace_members",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    workspaceId: varchar("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    userId: varchar("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: roleEnum("role").notNull().default("member"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => [
    index("workspace_members_workspace_idx").on(table.workspaceId),
    index("workspace_members_user_idx").on(table.userId),
  ]
);

export const workspaceMembersRelations = relations(
  workspaceMembers,
  ({ one }) => ({
    workspace: one(workspaces, {
      fields: [workspaceMembers.workspaceId],
      references: [workspaces.id],
    }),
    user: one(users, {
      fields: [workspaceMembers.userId],
      references: [users.id],
    }),
  })
);

// Boards
export const boards = pgTable(
  "boards",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    workspaceId: varchar("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    description: text("description"),
    backgroundColor: varchar("background_color").default("#0079BF"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => [index("boards_workspace_idx").on(table.workspaceId)]
);

export const boardsRelations = relations(boards, ({ one, many }) => ({
  workspace: one(workspaces, {
    fields: [boards.workspaceId],
    references: [workspaces.id],
  }),
  members: many(boardMembers),
  lists: many(lists),
  labels: many(labels),
}));

// Board Members (with roles)
export const boardMembers = pgTable(
  "board_members",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    boardId: varchar("board_id")
      .notNull()
      .references(() => boards.id, { onDelete: "cascade" }),
    userId: varchar("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: roleEnum("role").notNull().default("member"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => [
    index("board_members_board_idx").on(table.boardId),
    index("board_members_user_idx").on(table.userId),
  ]
);

export const boardMembersRelations = relations(boardMembers, ({ one }) => ({
  board: one(boards, {
    fields: [boardMembers.boardId],
    references: [boards.id],
  }),
  user: one(users, {
    fields: [boardMembers.userId],
    references: [users.id],
  }),
}));

// Lists
export const lists = pgTable(
  "lists",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    boardId: varchar("board_id")
      .notNull()
      .references(() => boards.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    orderingIndex: real("ordering_index").notNull(),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => [
    index("lists_board_idx").on(table.boardId),
    index("lists_order_idx").on(table.boardId, table.orderingIndex),
  ]
);

export const listsRelations = relations(lists, ({ one, many }) => ({
  board: one(boards, {
    fields: [lists.boardId],
    references: [boards.id],
  }),
  cards: many(cards),
}));

// Cards
export const cards = pgTable(
  "cards",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    listId: varchar("list_id")
      .notNull()
      .references(() => lists.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    description: text("description"),
    orderingIndex: real("ordering_index").notNull(),
    dueDate: timestamp("due_date"),
    coverImageUrl: varchar("cover_image_url"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => [
    index("cards_list_idx").on(table.listId),
    index("cards_order_idx").on(table.listId, table.orderingIndex),
  ]
);

export const cardsRelations = relations(cards, ({ one, many }) => ({
  list: one(lists, {
    fields: [cards.listId],
    references: [lists.id],
  }),
  members: many(cardMembers),
  labels: many(cardLabels),
  checklists: many(checklists),
  comments: many(comments),
  activities: many(activities),
}));

// Card Members
export const cardMembers = pgTable(
  "card_members",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    cardId: varchar("card_id")
      .notNull()
      .references(() => cards.id, { onDelete: "cascade" }),
    userId: varchar("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => [
    index("card_members_card_idx").on(table.cardId),
    index("card_members_user_idx").on(table.userId),
  ]
);

export const cardMembersRelations = relations(cardMembers, ({ one }) => ({
  card: one(cards, {
    fields: [cardMembers.cardId],
    references: [cards.id],
  }),
  user: one(users, {
    fields: [cardMembers.userId],
    references: [users.id],
  }),
}));

// Labels
export const labels = pgTable(
  "labels",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    boardId: varchar("board_id")
      .notNull()
      .references(() => boards.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    color: varchar("color").notNull(),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => [index("labels_board_idx").on(table.boardId)]
);

export const labelsRelations = relations(labels, ({ one, many }) => ({
  board: one(boards, {
    fields: [labels.boardId],
    references: [boards.id],
  }),
  cardLabels: many(cardLabels),
}));

// Card Labels (junction table)
export const cardLabels = pgTable(
  "card_labels",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    cardId: varchar("card_id")
      .notNull()
      .references(() => cards.id, { onDelete: "cascade" }),
    labelId: varchar("label_id")
      .notNull()
      .references(() => labels.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => [
    index("card_labels_card_idx").on(table.cardId),
    index("card_labels_label_idx").on(table.labelId),
  ]
);

export const cardLabelsRelations = relations(cardLabels, ({ one }) => ({
  card: one(cards, {
    fields: [cardLabels.cardId],
    references: [cards.id],
  }),
  label: one(labels, {
    fields: [cardLabels.labelId],
    references: [labels.id],
  }),
}));

// Checklists
export const checklists = pgTable(
  "checklists",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    cardId: varchar("card_id")
      .notNull()
      .references(() => cards.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => [index("checklists_card_idx").on(table.cardId)]
);

export const checklistsRelations = relations(checklists, ({ one, many }) => ({
  card: one(cards, {
    fields: [checklists.cardId],
    references: [cards.id],
  }),
  items: many(checklistItems),
}));

// Checklist Items
export const checklistItems = pgTable(
  "checklist_items",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    checklistId: varchar("checklist_id")
      .notNull()
      .references(() => checklists.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    completed: boolean("completed").notNull().default(false),
    orderingIndex: real("ordering_index").notNull(),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => [
    index("checklist_items_checklist_idx").on(table.checklistId),
    index("checklist_items_order_idx").on(
      table.checklistId,
      table.orderingIndex
    ),
  ]
);

export const checklistItemsRelations = relations(
  checklistItems,
  ({ one }) => ({
    checklist: one(checklists, {
      fields: [checklistItems.checklistId],
      references: [checklists.id],
    }),
  })
);

// Comments
export const comments = pgTable(
  "comments",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    cardId: varchar("card_id")
      .notNull()
      .references(() => cards.id, { onDelete: "cascade" }),
    userId: varchar("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    text: text("text").notNull(),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow(),
  },
  (table) => [
    index("comments_card_idx").on(table.cardId),
    index("comments_user_idx").on(table.userId),
  ]
);

export const commentsRelations = relations(comments, ({ one }) => ({
  card: one(cards, {
    fields: [comments.cardId],
    references: [cards.id],
  }),
  user: one(users, {
    fields: [comments.userId],
    references: [users.id],
  }),
}));

// Activities (audit log)
export const activities = pgTable(
  "activities",
  {
    id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
    cardId: varchar("card_id")
      .notNull()
      .references(() => cards.id, { onDelete: "cascade" }),
    userId: varchar("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    action: text("action").notNull(),
    metadata: jsonb("metadata"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => [
    index("activities_card_idx").on(table.cardId),
    index("activities_user_idx").on(table.userId),
  ]
);

export const activitiesRelations = relations(activities, ({ one }) => ({
  card: one(cards, {
    fields: [activities.cardId],
    references: [cards.id],
  }),
  user: one(users, {
    fields: [activities.userId],
    references: [users.id],
  }),
}));

// Zod schemas for inserts
export const upsertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertWorkspaceSchema = createInsertSchema(workspaces).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertWorkspaceMemberSchema = createInsertSchema(
  workspaceMembers
).omit({
  id: true,
  createdAt: true,
});

export const insertBoardSchema = createInsertSchema(boards).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBoardMemberSchema = createInsertSchema(boardMembers).omit({
  id: true,
  createdAt: true,
});

export const insertListSchema = createInsertSchema(lists).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCardSchema = createInsertSchema(cards).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCardMemberSchema = createInsertSchema(cardMembers).omit({
  id: true,
  createdAt: true,
});

export const insertLabelSchema = createInsertSchema(labels).omit({
  id: true,
  createdAt: true,
});

export const insertCardLabelSchema = createInsertSchema(cardLabels).omit({
  id: true,
  createdAt: true,
});

export const insertChecklistSchema = createInsertSchema(checklists).omit({
  id: true,
  createdAt: true,
});

export const insertChecklistItemSchema = createInsertSchema(
  checklistItems
).omit({
  id: true,
  createdAt: true,
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
});

// TypeScript types
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertWorkspace = z.infer<typeof insertWorkspaceSchema>;
export type Workspace = typeof workspaces.$inferSelect;

export type InsertWorkspaceMember = z.infer<typeof insertWorkspaceMemberSchema>;
export type WorkspaceMember = typeof workspaceMembers.$inferSelect;

export type InsertBoard = z.infer<typeof insertBoardSchema>;
export type Board = typeof boards.$inferSelect;

export type InsertBoardMember = z.infer<typeof insertBoardMemberSchema>;
export type BoardMember = typeof boardMembers.$inferSelect;

export type InsertList = z.infer<typeof insertListSchema>;
export type List = typeof lists.$inferSelect;

export type InsertCard = z.infer<typeof insertCardSchema>;
export type Card = typeof cards.$inferSelect;

export type InsertCardMember = z.infer<typeof insertCardMemberSchema>;
export type CardMember = typeof cardMembers.$inferSelect;

export type InsertLabel = z.infer<typeof insertLabelSchema>;
export type Label = typeof labels.$inferSelect;

export type InsertCardLabel = z.infer<typeof insertCardLabelSchema>;
export type CardLabel = typeof cardLabels.$inferSelect;

export type InsertChecklist = z.infer<typeof insertChecklistSchema>;
export type Checklist = typeof checklists.$inferSelect;

export type InsertChecklistItem = z.infer<typeof insertChecklistItemSchema>;
export type ChecklistItem = typeof checklistItems.$inferSelect;

export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;

export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

// Extended types with relations for frontend use
export type CardWithDetails = Card & {
  labels: (CardLabel & { label: Label })[];
  members: (CardMember & { user: User })[];
  checklists: (Checklist & { items: ChecklistItem[] })[];
  comments: (Comment & { user: User })[];
  activities: (Activity & { user: User })[];
};

export type ListWithCards = List & {
  cards: CardWithDetails[];
};

export type BoardWithLists = Board & {
  lists: ListWithCards[];
  members: (BoardMember & { user: User })[];
  labels: Label[];
};

export type WorkspaceWithBoards = Workspace & {
  members: (WorkspaceMember & { user: User })[];
  boards: Board[];
};
