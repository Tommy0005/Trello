// API routes and WebSocket server
import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import {
  insertWorkspaceSchema,
  insertBoardSchema,
  insertListSchema,
  insertCardSchema,
  insertChecklistSchema,
  insertChecklistItemSchema,
  insertCommentSchema,
  insertLabelSchema,
} from "@shared/schema";

// WebSocket connection map: boardId -> Set of WebSocket connections
const boardConnections = new Map<string, Set<WebSocket>>();

// Helper to broadcast to all connections in a board
function broadcastToBoard(boardId: string, message: any) {
  const connections = boardConnections.get(boardId);
  if (connections) {
    const payload = JSON.stringify(message);
    connections.forEach((ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(payload);
      }
    });
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware - referenced from javascript_log_in_with_replit blueprint
  await setupAuth(app);

  // Auth routes
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Workspace routes
  app.get("/api/workspaces", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const workspaces = await storage.getUserWorkspaces(userId);
      
      // Add member count for each workspace
      const workspacesWithCount = await Promise.all(
        workspaces.map(async (workspace) => {
          const members = await storage.getWorkspaceMembers(workspace.id);
          return { ...workspace, memberCount: members.length };
        })
      );
      
      res.json(workspacesWithCount);
    } catch (error) {
      console.error("Error fetching workspaces:", error);
      res.status(500).json({ message: "Failed to fetch workspaces" });
    }
  });

  app.get("/api/workspaces/:id", isAuthenticated, async (req, res) => {
    try {
      const workspace = await storage.getWorkspace(req.params.id);
      if (!workspace) {
        return res.status(404).json({ message: "Workspace not found" });
      }
      res.json(workspace);
    } catch (error) {
      console.error("Error fetching workspace:", error);
      res.status(500).json({ message: "Failed to fetch workspace" });
    }
  });

  app.post("/api/workspaces", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const data = insertWorkspaceSchema.parse(req.body);
      
      const workspace = await storage.createWorkspace(data);
      
      // Add creator as admin
      await storage.addWorkspaceMember({
        workspaceId: workspace.id,
        userId,
        role: "admin",
      });
      
      res.json(workspace);
    } catch (error: any) {
      console.error("Error creating workspace:", error);
      res.status(400).json({ message: error.message || "Failed to create workspace" });
    }
  });

  // Board routes
  app.get("/api/workspaces/:workspaceId/boards", isAuthenticated, async (req, res) => {
    try {
      const boards = await storage.getWorkspaceBoards(req.params.workspaceId);
      res.json(boards);
    } catch (error) {
      console.error("Error fetching boards:", error);
      res.status(500).json({ message: "Failed to fetch boards" });
    }
  });

  app.get("/api/boards/:id", isAuthenticated, async (req, res) => {
    try {
      const board = await storage.getBoard(req.params.id);
      if (!board) {
        return res.status(404).json({ message: "Board not found" });
      }

      // Fetch all lists with their cards
      const lists = await storage.getBoardLists(board.id);
      const listsWithCards = await Promise.all(
        lists.map(async (list) => {
          const cards = await storage.getListCards(list.id);
          
          // Fetch card details in parallel
          const cardsWithDetails = await Promise.all(
            cards.map(async (card) => {
              const [labels, members, checklists, comments] = await Promise.all([
                storage.getCardLabels(card.id),
                storage.getCardMembers(card.id),
                storage.getCardChecklists(card.id),
                storage.getCardComments(card.id),
              ]);

              // Fetch label and user details
              const labelsWithData = await Promise.all(
                labels.map(async (cl) => {
                  const label = await storage.getLabel(cl.labelId);
                  return { ...cl, label: label! };
                })
              );

              const membersWithData = await Promise.all(
                members.map(async (cm) => {
                  const user = await storage.getUser(cm.userId);
                  return { ...cm, user: user! };
                })
              );

              const checklistsWithItems = await Promise.all(
                checklists.map(async (checklist) => {
                  const items = await storage.getChecklistItems(checklist.id);
                  return { ...checklist, items };
                })
              );

              const commentsWithUsers = await Promise.all(
                comments.map(async (comment) => {
                  const user = await storage.getUser(comment.userId);
                  return { ...comment, user: user! };
                })
              );

              return {
                ...card,
                labels: labelsWithData,
                members: membersWithData,
                checklists: checklistsWithItems,
                comments: commentsWithUsers,
                activities: [],
              };
            })
          );

          return { ...list, cards: cardsWithDetails };
        })
      );

      // Fetch board labels and members
      const [boardLabels, boardMembers] = await Promise.all([
        storage.getBoardLabels(board.id),
        storage.getBoardMembers(board.id),
      ]);

      const boardMembersWithUsers = await Promise.all(
        boardMembers.map(async (bm) => {
          const user = await storage.getUser(bm.userId);
          return { ...bm, user: user! };
        })
      );

      res.json({
        ...board,
        lists: listsWithCards,
        labels: boardLabels,
        members: boardMembersWithUsers,
      });
    } catch (error) {
      console.error("Error fetching board:", error);
      res.status(500).json({ message: "Failed to fetch board" });
    }
  });

  app.post("/api/boards", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const data = insertBoardSchema.parse(req.body);
      
      const board = await storage.createBoard(data);
      
      // Add creator as admin
      await storage.addBoardMember({
        boardId: board.id,
        userId,
        role: "admin",
      });
      
      res.json(board);
    } catch (error: any) {
      console.error("Error creating board:", error);
      res.status(400).json({ message: error.message || "Failed to create board" });
    }
  });

  // List routes
  app.post("/api/lists", isAuthenticated, async (req, res) => {
    try {
      const data = insertListSchema.parse(req.body);
      const list = await storage.createList(data);
      
      broadcastToBoard(data.boardId, {
        type: "list:created",
        data: list,
      });
      
      res.json(list);
    } catch (error: any) {
      console.error("Error creating list:", error);
      res.status(400).json({ message: error.message || "Failed to create list" });
    }
  });

  app.patch("/api/lists/:id", isAuthenticated, async (req, res) => {
    try {
      const list = await storage.updateList(req.params.id, req.body);
      
      broadcastToBoard(list.boardId, {
        type: "list:updated",
        data: list,
      });
      
      res.json(list);
    } catch (error: any) {
      console.error("Error updating list:", error);
      res.status(400).json({ message: error.message || "Failed to update list" });
    }
  });

  app.delete("/api/lists/:id", isAuthenticated, async (req, res) => {
    try {
      const list = await storage.getList(req.params.id);
      if (!list) {
        return res.status(404).json({ message: "List not found" });
      }
      
      await storage.deleteList(req.params.id);
      
      broadcastToBoard(list.boardId, {
        type: "list:deleted",
        data: { id: req.params.id },
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting list:", error);
      res.status(500).json({ message: "Failed to delete list" });
    }
  });

  // Card routes
  app.get("/api/cards/:id", isAuthenticated, async (req, res) => {
    try {
      const card = await storage.getCard(req.params.id);
      if (!card) {
        return res.status(404).json({ message: "Card not found" });
      }

      const [labels, members, checklists, comments, activities] = await Promise.all([
        storage.getCardLabels(card.id),
        storage.getCardMembers(card.id),
        storage.getCardChecklists(card.id),
        storage.getCardComments(card.id),
        storage.getCardActivities(card.id),
      ]);

      const labelsWithData = await Promise.all(
        labels.map(async (cl) => {
          const label = await storage.getLabel(cl.labelId);
          return { ...cl, label: label! };
        })
      );

      const membersWithData = await Promise.all(
        members.map(async (cm) => {
          const user = await storage.getUser(cm.userId);
          return { ...cm, user: user! };
        })
      );

      const checklistsWithItems = await Promise.all(
        checklists.map(async (checklist) => {
          const items = await storage.getChecklistItems(checklist.id);
          return { ...checklist, items };
        })
      );

      const commentsWithUsers = await Promise.all(
        comments.map(async (comment) => {
          const user = await storage.getUser(comment.userId);
          return { ...comment, user: user! };
        })
      );

      const activitiesWithUsers = await Promise.all(
        activities.map(async (activity) => {
          const user = await storage.getUser(activity.userId);
          return { ...activity, user: user! };
        })
      );

      res.json({
        ...card,
        labels: labelsWithData,
        members: membersWithData,
        checklists: checklistsWithItems,
        comments: commentsWithUsers,
        activities: activitiesWithUsers,
      });
    } catch (error) {
      console.error("Error fetching card:", error);
      res.status(500).json({ message: "Failed to fetch card" });
    }
  });

  app.post("/api/cards", isAuthenticated, async (req, res) => {
    try {
      const data = insertCardSchema.parse(req.body);
      const card = await storage.createCard(data);
      
      const list = await storage.getList(card.listId);
      if (list) {
        broadcastToBoard(list.boardId, {
          type: "card:created",
          data: card,
        });
      }
      
      res.json(card);
    } catch (error: any) {
      console.error("Error creating card:", error);
      res.status(400).json({ message: error.message || "Failed to create card" });
    }
  });

  app.patch("/api/cards/:id", isAuthenticated, async (req, res) => {
    try {
      const card = await storage.updateCard(req.params.id, req.body);
      
      const list = await storage.getList(card.listId);
      if (list) {
        broadcastToBoard(list.boardId, {
          type: "card:updated",
          data: card,
        });
      }
      
      res.json(card);
    } catch (error: any) {
      console.error("Error updating card:", error);
      res.status(400).json({ message: error.message || "Failed to update card" });
    }
  });

  app.delete("/api/cards/:id", isAuthenticated, async (req, res) => {
    try {
      const card = await storage.getCard(req.params.id);
      if (!card) {
        return res.status(404).json({ message: "Card not found" });
      }
      
      const list = await storage.getList(card.listId);
      await storage.deleteCard(req.params.id);
      
      if (list) {
        broadcastToBoard(list.boardId, {
          type: "card:deleted",
          data: { id: req.params.id },
        });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting card:", error);
      res.status(500).json({ message: "Failed to delete card" });
    }
  });

  app.post("/api/cards/:id/move", isAuthenticated, async (req, res) => {
    try {
      const { listId, orderingIndex } = req.body;
      const card = await storage.moveCard(req.params.id, listId, orderingIndex);
      
      const list = await storage.getList(card.listId);
      if (list) {
        broadcastToBoard(list.boardId, {
          type: "card:moved",
          data: card,
        });
      }
      
      res.json(card);
    } catch (error) {
      console.error("Error moving card:", error);
      res.status(500).json({ message: "Failed to move card" });
    }
  });

  // Comment routes
  app.post("/api/comments", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const data = insertCommentSchema.parse(req.body);
      
      const comment = await storage.createComment({
        ...data,
        userId,
      });
      
      const card = await storage.getCard(comment.cardId);
      if (card) {
        const list = await storage.getList(card.listId);
        if (list) {
          broadcastToBoard(list.boardId, {
            type: "comment:new",
            data: comment,
          });
        }
      }
      
      res.json(comment);
    } catch (error: any) {
      console.error("Error creating comment:", error);
      res.status(400).json({ message: error.message || "Failed to create comment" });
    }
  });

  // Checklist routes
  app.post("/api/checklists", isAuthenticated, async (req, res) => {
    try {
      const data = insertChecklistSchema.parse(req.body);
      const checklist = await storage.createChecklist(data);
      
      const card = await storage.getCard(checklist.cardId);
      if (card) {
        const list = await storage.getList(card.listId);
        if (list) {
          broadcastToBoard(list.boardId, {
            type: "checklist:created",
            data: checklist,
          });
        }
      }
      
      res.json(checklist);
    } catch (error: any) {
      console.error("Error creating checklist:", error);
      res.status(400).json({ message: error.message || "Failed to create checklist" });
    }
  });

  app.post("/api/checklist-items", isAuthenticated, async (req, res) => {
    try {
      const data = insertChecklistItemSchema.parse(req.body);
      const item = await storage.createChecklistItem(data);
      res.json(item);
    } catch (error: any) {
      console.error("Error creating checklist item:", error);
      res.status(400).json({ message: error.message || "Failed to create checklist item" });
    }
  });

  app.patch("/api/checklist-items/:id", isAuthenticated, async (req, res) => {
    try {
      const item = await storage.updateChecklistItem(req.params.id, req.body);
      res.json(item);
    } catch (error: any) {
      console.error("Error updating checklist item:", error);
      res.status(400).json({ message: error.message || "Failed to update checklist item" });
    }
  });

  // Label routes
  app.get("/api/boards/:boardId/labels", isAuthenticated, async (req, res) => {
    try {
      const labels = await storage.getBoardLabels(req.params.boardId);
      res.json(labels);
    } catch (error) {
      console.error("Error fetching labels:", error);
      res.status(500).json({ message: "Failed to fetch labels" });
    }
  });

  app.post("/api/labels", isAuthenticated, async (req, res) => {
    try {
      const data = insertLabelSchema.parse(req.body);
      const label = await storage.createLabel(data);
      res.json(label);
    } catch (error: any) {
      console.error("Error creating label:", error);
      res.status(400).json({ message: error.message || "Failed to create label" });
    }
  });

  // HTTP server
  const httpServer = createServer(app);

  // WebSocket server - referenced from javascript_websocket blueprint
  const wss = new WebSocketServer({ server: httpServer, path: "/ws" });

  wss.on("connection", (ws: WebSocket) => {
    let currentBoardId: string | null = null;

    ws.on("message", (message: string) => {
      try {
        const data = JSON.parse(message.toString());

        if (data.type === "subscribe" && data.boardId) {
          // Unsubscribe from previous board if any
          if (currentBoardId) {
            const connections = boardConnections.get(currentBoardId);
            if (connections) {
              connections.delete(ws);
            }
          }

          // Subscribe to new board
          currentBoardId = data.boardId;
          if (!boardConnections.has(currentBoardId)) {
            boardConnections.set(currentBoardId, new Set());
          }
          boardConnections.get(currentBoardId)!.add(ws);

          ws.send(JSON.stringify({ type: "subscribed", boardId: currentBoardId }));
        }
      } catch (error) {
        console.error("WebSocket message error:", error);
      }
    });

    ws.on("close", () => {
      if (currentBoardId) {
        const connections = boardConnections.get(currentBoardId);
        if (connections) {
          connections.delete(ws);
          if (connections.size === 0) {
            boardConnections.delete(currentBoardId);
          }
        }
      }
    });
  });

  return httpServer;
}
