// Database storage implementation
import { db } from "./db";
import { eq, and, desc, asc, sql } from "drizzle-orm";
import {
  users,
  workspaces,
  workspaceMembers,
  boards,
  boardMembers,
  lists,
  cards,
  cardMembers,
  labels,
  cardLabels,
  checklists,
  checklistItems,
  comments,
  activities,
  type UpsertUser,
  type User,
  type InsertWorkspace,
  type Workspace,
  type InsertWorkspaceMember,
  type WorkspaceMember,
  type InsertBoard,
  type Board,
  type InsertBoardMember,
  type BoardMember,
  type InsertList,
  type List,
  type InsertCard,
  type Card,
  type InsertCardMember,
  type CardMember,
  type InsertLabel,
  type Label,
  type InsertCardLabel,
  type CardLabel,
  type InsertChecklist,
  type Checklist,
  type InsertChecklistItem,
  type ChecklistItem,
  type InsertComment,
  type Comment,
  type InsertActivity,
  type Activity,
} from "@shared/schema";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Workspace operations
  createWorkspace(workspace: InsertWorkspace): Promise<Workspace>;
  getWorkspace(id: string): Promise<Workspace | undefined>;
  getUserWorkspaces(userId: string): Promise<Workspace[]>;
  updateWorkspace(id: string, data: Partial<InsertWorkspace>): Promise<Workspace>;
  deleteWorkspace(id: string): Promise<void>;

  // Workspace Member operations
  addWorkspaceMember(member: InsertWorkspaceMember): Promise<WorkspaceMember>;
  getWorkspaceMembers(workspaceId: string): Promise<WorkspaceMember[]>;
  removeWorkspaceMember(workspaceId: string, userId: string): Promise<void>;

  // Board operations
  createBoard(board: InsertBoard): Promise<Board>;
  getBoard(id: string): Promise<Board | undefined>;
  getWorkspaceBoards(workspaceId: string): Promise<Board[]>;
  updateBoard(id: string, data: Partial<InsertBoard>): Promise<Board>;
  deleteBoard(id: string): Promise<void>;

  // Board Member operations
  addBoardMember(member: InsertBoardMember): Promise<BoardMember>;
  getBoardMembers(boardId: string): Promise<BoardMember[]>;
  removeBoardMember(boardId: string, userId: string): Promise<void>;

  // List operations
  createList(list: InsertList): Promise<List>;
  getList(id: string): Promise<List | undefined>;
  getBoardLists(boardId: string): Promise<List[]>;
  updateList(id: string, data: Partial<InsertList>): Promise<List>;
  deleteList(id: string): Promise<void>;

  // Card operations
  createCard(card: InsertCard): Promise<Card>;
  getCard(id: string): Promise<Card | undefined>;
  getListCards(listId: string): Promise<Card[]>;
  updateCard(id: string, data: Partial<InsertCard>): Promise<Card>;
  deleteCard(id: string): Promise<void>;
  moveCard(cardId: string, newListId: string, newOrderingIndex: number): Promise<Card>;

  // Card Member operations
  addCardMember(member: InsertCardMember): Promise<CardMember>;
  getCardMembers(cardId: string): Promise<CardMember[]>;
  removeCardMember(cardId: string, userId: string): Promise<void>;

  // Label operations
  createLabel(label: InsertLabel): Promise<Label>;
  getLabel(id: string): Promise<Label | undefined>;
  getBoardLabels(boardId: string): Promise<Label[]>;
  updateLabel(id: string, data: Partial<InsertLabel>): Promise<Label>;
  deleteLabel(id: string): Promise<void>;

  // Card Label operations
  addCardLabel(cardLabel: InsertCardLabel): Promise<CardLabel>;
  getCardLabels(cardId: string): Promise<CardLabel[]>;
  removeCardLabel(cardId: string, labelId: string): Promise<void>;

  // Checklist operations
  createChecklist(checklist: InsertChecklist): Promise<Checklist>;
  getChecklist(id: string): Promise<Checklist | undefined>;
  getCardChecklists(cardId: string): Promise<Checklist[]>;
  updateChecklist(id: string, data: Partial<InsertChecklist>): Promise<Checklist>;
  deleteChecklist(id: string): Promise<void>;

  // Checklist Item operations
  createChecklistItem(item: InsertChecklistItem): Promise<ChecklistItem>;
  getChecklistItems(checklistId: string): Promise<ChecklistItem[]>;
  updateChecklistItem(id: string, data: Partial<InsertChecklistItem>): Promise<ChecklistItem>;
  deleteChecklistItem(id: string): Promise<void>;

  // Comment operations
  createComment(comment: InsertComment): Promise<Comment>;
  getComment(id: string): Promise<Comment | undefined>;
  getCardComments(cardId: string): Promise<Comment[]>;
  updateComment(id: string, text: string): Promise<Comment>;
  deleteComment(id: string): Promise<void>;

  // Activity operations
  createActivity(activity: InsertActivity): Promise<Activity>;
  getCardActivities(cardId: string): Promise<Activity[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Workspace operations
  async createWorkspace(workspace: InsertWorkspace): Promise<Workspace> {
    const [result] = await db.insert(workspaces).values(workspace).returning();
    return result;
  }

  async getWorkspace(id: string): Promise<Workspace | undefined> {
    const [workspace] = await db
      .select()
      .from(workspaces)
      .where(eq(workspaces.id, id));
    return workspace || undefined;
  }

  async getUserWorkspaces(userId: string): Promise<Workspace[]> {
    const result = await db
      .select({ workspace: workspaces })
      .from(workspaces)
      .innerJoin(
        workspaceMembers,
        eq(workspaces.id, workspaceMembers.workspaceId)
      )
      .where(eq(workspaceMembers.userId, userId));
    return result.map((r) => r.workspace);
  }

  async updateWorkspace(
    id: string,
    data: Partial<InsertWorkspace>
  ): Promise<Workspace> {
    const [updated] = await db
      .update(workspaces)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(workspaces.id, id))
      .returning();
    return updated;
  }

  async deleteWorkspace(id: string): Promise<void> {
    await db.delete(workspaces).where(eq(workspaces.id, id));
  }

  // Workspace Member operations
  async addWorkspaceMember(member: InsertWorkspaceMember): Promise<WorkspaceMember> {
    const [result] = await db.insert(workspaceMembers).values(member).returning();
    return result;
  }

  async getWorkspaceMembers(workspaceId: string): Promise<WorkspaceMember[]> {
    return await db
      .select()
      .from(workspaceMembers)
      .where(eq(workspaceMembers.workspaceId, workspaceId));
  }

  async removeWorkspaceMember(workspaceId: string, userId: string): Promise<void> {
    await db
      .delete(workspaceMembers)
      .where(
        and(
          eq(workspaceMembers.workspaceId, workspaceId),
          eq(workspaceMembers.userId, userId)
        )
      );
  }

  // Board operations
  async createBoard(board: InsertBoard): Promise<Board> {
    const [result] = await db.insert(boards).values(board).returning();
    return result;
  }

  async getBoard(id: string): Promise<Board | undefined> {
    const [board] = await db.select().from(boards).where(eq(boards.id, id));
    return board || undefined;
  }

  async getWorkspaceBoards(workspaceId: string): Promise<Board[]> {
    return await db
      .select()
      .from(boards)
      .where(eq(boards.workspaceId, workspaceId))
      .orderBy(desc(boards.createdAt));
  }

  async updateBoard(id: string, data: Partial<InsertBoard>): Promise<Board> {
    const [updated] = await db
      .update(boards)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(boards.id, id))
      .returning();
    return updated;
  }

  async deleteBoard(id: string): Promise<void> {
    await db.delete(boards).where(eq(boards.id, id));
  }

  // Board Member operations
  async addBoardMember(member: InsertBoardMember): Promise<BoardMember> {
    const [result] = await db.insert(boardMembers).values(member).returning();
    return result;
  }

  async getBoardMembers(boardId: string): Promise<BoardMember[]> {
    return await db
      .select()
      .from(boardMembers)
      .where(eq(boardMembers.boardId, boardId));
  }

  async removeBoardMember(boardId: string, userId: string): Promise<void> {
    await db
      .delete(boardMembers)
      .where(
        and(
          eq(boardMembers.boardId, boardId),
          eq(boardMembers.userId, userId)
        )
      );
  }

  // List operations
  async createList(list: InsertList): Promise<List> {
    const [result] = await db.insert(lists).values(list).returning();
    return result;
  }

  async getList(id: string): Promise<List | undefined> {
    const [list] = await db.select().from(lists).where(eq(lists.id, id));
    return list || undefined;
  }

  async getBoardLists(boardId: string): Promise<List[]> {
    return await db
      .select()
      .from(lists)
      .where(eq(lists.boardId, boardId))
      .orderBy(asc(lists.orderingIndex));
  }

  async updateList(id: string, data: Partial<InsertList>): Promise<List> {
    const [updated] = await db
      .update(lists)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(lists.id, id))
      .returning();
    return updated;
  }

  async deleteList(id: string): Promise<void> {
    await db.delete(lists).where(eq(lists.id, id));
  }

  // Card operations
  async createCard(card: InsertCard): Promise<Card> {
    const [result] = await db.insert(cards).values(card).returning();
    return result;
  }

  async getCard(id: string): Promise<Card | undefined> {
    const [card] = await db.select().from(cards).where(eq(cards.id, id));
    return card || undefined;
  }

  async getListCards(listId: string): Promise<Card[]> {
    return await db
      .select()
      .from(cards)
      .where(eq(cards.listId, listId))
      .orderBy(asc(cards.orderingIndex));
  }

  async updateCard(id: string, data: Partial<InsertCard>): Promise<Card> {
    const [updated] = await db
      .update(cards)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(cards.id, id))
      .returning();
    return updated;
  }

  async deleteCard(id: string): Promise<void> {
    await db.delete(cards).where(eq(cards.id, id));
  }

  async moveCard(
    cardId: string,
    newListId: string,
    newOrderingIndex: number
  ): Promise<Card> {
    const [updated] = await db
      .update(cards)
      .set({
        listId: newListId,
        orderingIndex: newOrderingIndex,
        updatedAt: new Date(),
      })
      .where(eq(cards.id, cardId))
      .returning();
    return updated;
  }

  // Card Member operations
  async addCardMember(member: InsertCardMember): Promise<CardMember> {
    const [result] = await db.insert(cardMembers).values(member).returning();
    return result;
  }

  async getCardMembers(cardId: string): Promise<CardMember[]> {
    return await db
      .select()
      .from(cardMembers)
      .where(eq(cardMembers.cardId, cardId));
  }

  async removeCardMember(cardId: string, userId: string): Promise<void> {
    await db
      .delete(cardMembers)
      .where(
        and(
          eq(cardMembers.cardId, cardId),
          eq(cardMembers.userId, userId)
        )
      );
  }

  // Label operations
  async createLabel(label: InsertLabel): Promise<Label> {
    const [result] = await db.insert(labels).values(label).returning();
    return result;
  }

  async getLabel(id: string): Promise<Label | undefined> {
    const [label] = await db.select().from(labels).where(eq(labels.id, id));
    return label || undefined;
  }

  async getBoardLabels(boardId: string): Promise<Label[]> {
    return await db
      .select()
      .from(labels)
      .where(eq(labels.boardId, boardId))
      .orderBy(asc(labels.createdAt));
  }

  async updateLabel(id: string, data: Partial<InsertLabel>): Promise<Label> {
    const [updated] = await db
      .update(labels)
      .set(data)
      .where(eq(labels.id, id))
      .returning();
    return updated;
  }

  async deleteLabel(id: string): Promise<void> {
    await db.delete(labels).where(eq(labels.id, id));
  }

  // Card Label operations
  async addCardLabel(cardLabel: InsertCardLabel): Promise<CardLabel> {
    const [result] = await db.insert(cardLabels).values(cardLabel).returning();
    return result;
  }

  async getCardLabels(cardId: string): Promise<CardLabel[]> {
    return await db
      .select()
      .from(cardLabels)
      .where(eq(cardLabels.cardId, cardId));
  }

  async removeCardLabel(cardId: string, labelId: string): Promise<void> {
    await db
      .delete(cardLabels)
      .where(
        and(
          eq(cardLabels.cardId, cardId),
          eq(cardLabels.labelId, labelId)
        )
      );
  }

  // Checklist operations
  async createChecklist(checklist: InsertChecklist): Promise<Checklist> {
    const [result] = await db.insert(checklists).values(checklist).returning();
    return result;
  }

  async getChecklist(id: string): Promise<Checklist | undefined> {
    const [checklist] = await db
      .select()
      .from(checklists)
      .where(eq(checklists.id, id));
    return checklist || undefined;
  }

  async getCardChecklists(cardId: string): Promise<Checklist[]> {
    return await db
      .select()
      .from(checklists)
      .where(eq(checklists.cardId, cardId))
      .orderBy(asc(checklists.createdAt));
  }

  async updateChecklist(
    id: string,
    data: Partial<InsertChecklist>
  ): Promise<Checklist> {
    const [updated] = await db
      .update(checklists)
      .set(data)
      .where(eq(checklists.id, id))
      .returning();
    return updated;
  }

  async deleteChecklist(id: string): Promise<void> {
    await db.delete(checklists).where(eq(checklists.id, id));
  }

  // Checklist Item operations
  async createChecklistItem(item: InsertChecklistItem): Promise<ChecklistItem> {
    const [result] = await db.insert(checklistItems).values(item).returning();
    return result;
  }

  async getChecklistItems(checklistId: string): Promise<ChecklistItem[]> {
    return await db
      .select()
      .from(checklistItems)
      .where(eq(checklistItems.checklistId, checklistId))
      .orderBy(asc(checklistItems.orderingIndex));
  }

  async updateChecklistItem(
    id: string,
    data: Partial<InsertChecklistItem>
  ): Promise<ChecklistItem> {
    const [updated] = await db
      .update(checklistItems)
      .set(data)
      .where(eq(checklistItems.id, id))
      .returning();
    return updated;
  }

  async deleteChecklistItem(id: string): Promise<void> {
    await db.delete(checklistItems).where(eq(checklistItems.id, id));
  }

  // Comment operations
  async createComment(comment: InsertComment): Promise<Comment> {
    const [result] = await db.insert(comments).values(comment).returning();
    return result;
  }

  async getComment(id: string): Promise<Comment | undefined> {
    const [comment] = await db
      .select()
      .from(comments)
      .where(eq(comments.id, id));
    return comment || undefined;
  }

  async getCardComments(cardId: string): Promise<Comment[]> {
    return await db
      .select()
      .from(comments)
      .where(eq(comments.cardId, cardId))
      .orderBy(desc(comments.createdAt));
  }

  async updateComment(id: string, text: string): Promise<Comment> {
    const [updated] = await db
      .update(comments)
      .set({ text, updatedAt: new Date() })
      .where(eq(comments.id, id))
      .returning();
    return updated;
  }

  async deleteComment(id: string): Promise<void> {
    await db.delete(comments).where(eq(comments.id, id));
  }

  // Activity operations
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [result] = await db.insert(activities).values(activity).returning();
    return result;
  }

  async getCardActivities(cardId: string): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .where(eq(activities.cardId, cardId))
      .orderBy(desc(activities.createdAt));
  }
}

export const storage = new DatabaseStorage();
