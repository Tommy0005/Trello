import { Button } from "@/components/ui/button";
import { Trello, CheckSquare, Users, Zap } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/20">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trello className="h-8 w-8 text-primary" data-testid="logo-icon" />
            <span className="text-2xl font-bold" data-testid="text-app-name">
              Kanban Board
            </span>
          </div>
          <Button
            onClick={() => (window.location.href = "/api/login")}
            size="lg"
            data-testid="button-login"
          >
            Log In
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h1
            className="text-5xl md:text-6xl font-bold tracking-tight"
            data-testid="text-hero-title"
          >
            Organize Your Work,{" "}
            <span className="text-primary">Visually</span>
          </h1>
          <p
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
            data-testid="text-hero-subtitle"
          >
            A powerful Kanban board for managing projects, tasks, and teams.
            Real-time collaboration made simple and beautiful.
          </p>
          <div className="flex gap-4 justify-center">
            <Button
              onClick={() => (window.location.href = "/api/login")}
              size="lg"
              className="text-lg px-8"
              data-testid="button-get-started"
            >
              Get Started
            </Button>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-3 gap-6 pt-16">
            <div className="p-6 rounded-lg bg-card border hover-elevate" data-testid="feature-card-boards">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 mx-auto">
                <Trello className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Visual Boards</h3>
              <p className="text-sm text-muted-foreground">
                Organize tasks with boards, lists, and cards. Drag and drop to
                prioritize.
              </p>
            </div>

            <div className="p-6 rounded-lg bg-card border hover-elevate" data-testid="feature-card-collaboration">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 mx-auto">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Real-time Collaboration</h3>
              <p className="text-sm text-muted-foreground">
                Work together seamlessly. See changes instantly as your team
                updates cards.
              </p>
            </div>

            <div className="p-6 rounded-lg bg-card border hover-elevate" data-testid="feature-card-productivity">
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 mx-auto">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Boost Productivity</h3>
              <p className="text-sm text-muted-foreground">
                Checklists, due dates, labels, and comments keep everyone on
                track.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
