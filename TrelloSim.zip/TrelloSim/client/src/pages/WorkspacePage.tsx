import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Link, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, ArrowLeft, Trello, LogOut } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Workspace, Board } from "@shared/schema";

const BOARD_COLORS = [
  { value: "#0079BF", label: "Blue" },
  { value: "#D29034", label: "Orange" },
  { value: "#519839", label: "Green" },
  { value: "#B04632", label: "Red" },
  { value: "#89609E", label: "Purple" },
  { value: "#CD5A91", label: "Pink" },
  { value: "#4BBF6B", label: "Lime" },
  { value: "#00AECC", label: "Sky" },
  { value: "#838C91", label: "Grey" },
];

export default function WorkspacePage() {
  const { workspaceId } = useParams();
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [boardName, setBoardName] = useState("");
  const [boardDescription, setBoardDescription] = useState("");
  const [boardColor, setBoardColor] = useState("#0079BF");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: workspace, isLoading: workspaceLoading } = useQuery<Workspace>({
    queryKey: ["/api/workspaces", workspaceId],
    enabled: isAuthenticated && !!workspaceId,
  });

  const { data: boards, isLoading: boardsLoading } = useQuery<Board[]>({
    queryKey: ["/api/workspaces", workspaceId, "boards"],
    enabled: isAuthenticated && !!workspaceId,
  });

  const createBoardMutation = useMutation({
    mutationFn: async () => {
      const result = await apiRequest("POST", "/api/boards", {
        workspaceId,
        name: boardName,
        description: boardDescription,
        backgroundColor: boardColor,
      });
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/workspaces", workspaceId, "boards"],
      });
      setIsCreateOpen(false);
      setBoardName("");
      setBoardDescription("");
      setBoardColor("#0079BF");
      toast({
        title: "Board created",
        description: "Your new board is ready to use.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create board. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (authLoading || workspaceLoading || boardsLoading) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-10 w-24" />
          </div>
        </header>
        <main className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <Skeleton className="h-10 w-64 mb-2" />
            <Skeleton className="h-5 w-96" />
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold" data-testid="text-workspace-name">
                {workspace?.name}
              </h1>
              {workspace?.description && (
                <p className="text-sm text-muted-foreground" data-testid="text-workspace-description">
                  {workspace.description}
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2" data-testid="user-info">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user?.profileImageUrl || undefined} />
                <AvatarFallback>
                  {user?.firstName?.[0]}
                  {user?.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium hidden md:inline" data-testid="text-username">
                {user?.firstName} {user?.lastName}
              </span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => (window.location.href = "/api/logout")}
              data-testid="button-logout"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <h2 className="text-2xl font-bold mb-2" data-testid="text-page-title">
            Boards
          </h2>
          <p className="text-muted-foreground" data-testid="text-page-subtitle">
            Manage your project boards and start organizing tasks
          </p>
        </div>

        {/* Boards Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4" data-testid="boards-grid">
          {/* Create New Board Card */}
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Card
                className="hover-elevate cursor-pointer border-dashed"
                data-testid="button-create-board"
              >
                <CardHeader className="flex flex-col items-center justify-center h-32">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                    <Plus className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-center">Create Board</CardTitle>
                </CardHeader>
              </Card>
            </DialogTrigger>
            <DialogContent data-testid="dialog-create-board">
              <DialogHeader>
                <DialogTitle>Create New Board</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Board Name</Label>
                  <Input
                    id="name"
                    placeholder="My Project Board"
                    value={boardName}
                    onChange={(e) => setBoardName(e.target.value)}
                    data-testid="input-board-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea
                    id="description"
                    placeholder="A brief description of this board..."
                    value={boardDescription}
                    onChange={(e) => setBoardDescription(e.target.value)}
                    data-testid="input-board-description"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="color">Background Color</Label>
                  <Select value={boardColor} onValueChange={setBoardColor}>
                    <SelectTrigger data-testid="select-board-color">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {BOARD_COLORS.map((color) => (
                        <SelectItem
                          key={color.value}
                          value={color.value}
                          data-testid={`option-color-${color.label.toLowerCase()}`}
                        >
                          <div className="flex items-center gap-2">
                            <div
                              className="h-4 w-4 rounded"
                              style={{ backgroundColor: color.value }}
                            />
                            {color.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setIsCreateOpen(false)}
                  data-testid="button-cancel"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => createBoardMutation.mutate()}
                  disabled={!boardName.trim() || createBoardMutation.isPending}
                  data-testid="button-submit"
                >
                  {createBoardMutation.isPending ? "Creating..." : "Create"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Board Cards */}
          {boards?.map((board) => (
            <Link
              key={board.id}
              href={`/board/${board.id}`}
              data-testid={`link-board-${board.id}`}
            >
              <Card
                className="hover-elevate cursor-pointer h-full overflow-hidden"
                style={{
                  background: `linear-gradient(135deg, ${board.backgroundColor} 0%, ${board.backgroundColor}dd 100%)`,
                }}
              >
                <CardHeader className="text-white">
                  <CardTitle className="flex items-center gap-2" data-testid={`text-board-name-${board.id}`}>
                    <Trello className="h-5 w-5" />
                    {board.name}
                  </CardTitle>
                  {board.description && (
                    <CardDescription className="text-white/90 line-clamp-2" data-testid={`text-board-description-${board.id}`}>
                      {board.description}
                    </CardDescription>
                  )}
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>

        {/* Empty State */}
        {boards && boards.length === 0 && (
          <div className="text-center py-12" data-testid="empty-state">
            <Trello className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-2xl font-semibold mb-2">No boards yet</h2>
            <p className="text-muted-foreground mb-6">
              Create your first board to start organizing tasks
            </p>
            <Button onClick={() => setIsCreateOpen(true)} data-testid="button-create-first-board">
              <Plus className="h-4 w-4 mr-2" />
              Create Board
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}
