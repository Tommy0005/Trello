import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useToast } from "@/hooks/use-toast";
import { Link, useParams, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, LogOut, Search, Filter, Plus, X } from "lucide-react";
import type { BoardWithLists } from "@shared/schema";
import { BoardList } from "@/components/BoardList";
import { CardModal } from "@/components/CardModal";
import { useUIStore } from "@/stores/uiStore";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";

export default function BoardPage() {
  const { boardId } = useParams();
  const [, navigate] = useLocation();
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const { filters, setSearch, clearFilters, openCardId, closeCard } = useUIStore();
  const [searchValue, setSearchValue] = useState(filters.search);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: board, isLoading: boardLoading } = useQuery<BoardWithLists>({
    queryKey: ["/api/boards", boardId],
    enabled: isAuthenticated && !!boardId,
  });

  // WebSocket connection for real-time updates
  useWebSocket(boardId);

  // Handle search with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      setSearch(searchValue);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchValue, setSearch]);

  const hasActiveFilters =
    filters.search ||
    filters.memberIds.length > 0 ||
    filters.labelIds.length > 0 ||
    filters.dueDate;

  if (authLoading || boardLoading) {
    return (
      <div className="min-h-screen flex flex-col" style={{ backgroundColor: "#0079BF" }}>
        <header className="bg-black/20 backdrop-blur-sm border-b border-white/10">
          <div className="px-4 py-3 flex items-center justify-between">
            <Skeleton className="h-8 w-48 bg-white/20" />
            <Skeleton className="h-8 w-24 bg-white/20" />
          </div>
        </header>
        <div className="flex-1 p-4 flex gap-3 overflow-x-auto">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="w-[272px] h-96 bg-white/20 flex-shrink-0" />
          ))}
        </div>
      </div>
    );
  }

  if (!board) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-2">Board not found</h2>
          <p className="text-muted-foreground mb-4">
            The board you're looking for doesn't exist or you don't have access.
          </p>
          <Button onClick={() => navigate("/")} data-testid="button-go-home">
            Go Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ backgroundColor: board.backgroundColor || "#0079BF" }}
      data-testid="board-page"
    >
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/20 flex-shrink-0"
              onClick={() => navigate(`/workspace/${board.workspaceId}`)}
              data-testid="button-back"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold text-white truncate" data-testid="text-board-name">
              {board.name}
            </h1>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            {/* Search */}
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/60" />
              <Input
                placeholder="Search cards..."
                value={searchValue}
                onChange={(e) => setSearchValue(e.target.value)}
                className="w-64 pl-9 bg-white/10 border-white/20 text-white placeholder:text-white/60 focus:bg-white/20"
                data-testid="input-search"
              />
              {searchValue && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-6 w-6 text-white/60 hover:text-white hover:bg-white/20"
                  onClick={() => setSearchValue("")}
                  data-testid="button-clear-search"
                >
                  <X className="h-3 w-3" />
                </Button>
              )}
            </div>

            {/* Filter Button */}
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-white hover:bg-white/20"
                  data-testid="button-filter"
                >
                  <Filter className="h-4 w-4 mr-2" />
                  Filter
                  {hasActiveFilters && (
                    <Badge variant="secondary" className="ml-2 h-5 px-1.5">
                      •
                    </Badge>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80" data-testid="popover-filters">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">Filters</h3>
                    {hasActiveFilters && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={clearFilters}
                        data-testid="button-clear-filters"
                      >
                        Clear all
                      </Button>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Filter functionality will be fully implemented in the integration phase
                  </p>
                </div>
              </PopoverContent>
            </Popover>

            {/* User Info */}
            <div className="flex items-center gap-2 hidden lg:flex" data-testid="user-info">
              <Avatar className="h-8 w-8 border-2 border-white/20">
                <AvatarImage src={user?.profileImageUrl || undefined} />
                <AvatarFallback className="bg-white/20 text-white">
                  {user?.firstName?.[0]}
                  {user?.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
            </div>

            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/20"
              onClick={() => (window.location.href = "/api/logout")}
              data-testid="button-logout"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Board Content */}
      <div className="flex-1 overflow-hidden">
        <BoardList boardId={board.id} lists={board.lists || []} />
      </div>

      {/* Card Modal */}
      {openCardId && <CardModal cardId={openCardId} onClose={closeCard} />}
    </div>
  );
}
