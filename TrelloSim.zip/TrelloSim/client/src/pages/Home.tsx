import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, LogOut, Trello, Users } from "lucide-react";
import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Workspace, User } from "@shared/schema";

export default function Home() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [workspaceName, setWorkspaceName] = useState("");
  const [workspaceDescription, setWorkspaceDescription] = useState("");

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [isAuthenticated, authLoading, toast]);

  const { data: workspaces, isLoading: workspacesLoading } = useQuery<
    (Workspace & { memberCount: number })[]
  >({
    queryKey: ["/api/workspaces"],
    enabled: isAuthenticated,
  });

  const createWorkspaceMutation = useMutation({
    mutationFn: async () => {
      const result = await apiRequest("POST", "/api/workspaces", {
        name: workspaceName,
        description: workspaceDescription,
      });
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workspaces"] });
      setIsCreateOpen(false);
      setWorkspaceName("");
      setWorkspaceDescription("");
      toast({
        title: "Workspace created",
        description: "Your new workspace is ready to use.",
      });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to create workspace. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (authLoading || workspacesLoading) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Trello className="h-8 w-8 text-primary" />
              <span className="text-2xl font-bold">Kanban Board</span>
            </div>
            <Skeleton className="h-10 w-24" />
          </div>
        </header>
        <main className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <Skeleton className="h-10 w-64 mb-2" />
            <Skeleton className="h-5 w-96" />
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Trello className="h-8 w-8 text-primary" data-testid="logo-icon" />
            <span className="text-2xl font-bold" data-testid="text-app-name">
              Kanban Board
            </span>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2" data-testid="user-info">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user?.profileImageUrl || undefined} />
                <AvatarFallback>
                  {user?.firstName?.[0]}
                  {user?.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium hidden md:inline" data-testid="text-username">
                {user?.firstName} {user?.lastName}
              </span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => (window.location.href = "/api/logout")}
              data-testid="button-logout"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-2" data-testid="text-page-title">
            Your Workspaces
          </h1>
          <p className="text-muted-foreground" data-testid="text-page-subtitle">
            Select a workspace to view and manage your boards
          </p>
        </div>

        {/* Workspaces Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3" data-testid="workspace-grid">
          {/* Create New Workspace Card */}
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Card
                className="hover-elevate cursor-pointer border-dashed"
                data-testid="button-create-workspace"
              >
                <CardHeader className="flex flex-col items-center justify-center h-32">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                    <Plus className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-center">
                    Create Workspace
                  </CardTitle>
                </CardHeader>
              </Card>
            </DialogTrigger>
            <DialogContent data-testid="dialog-create-workspace">
              <DialogHeader>
                <DialogTitle>Create New Workspace</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Workspace Name</Label>
                  <Input
                    id="name"
                    placeholder="My Workspace"
                    value={workspaceName}
                    onChange={(e) => setWorkspaceName(e.target.value)}
                    data-testid="input-workspace-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea
                    id="description"
                    placeholder="A brief description of this workspace..."
                    value={workspaceDescription}
                    onChange={(e) => setWorkspaceDescription(e.target.value)}
                    data-testid="input-workspace-description"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setIsCreateOpen(false)}
                  data-testid="button-cancel"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => createWorkspaceMutation.mutate()}
                  disabled={!workspaceName.trim() || createWorkspaceMutation.isPending}
                  data-testid="button-submit"
                >
                  {createWorkspaceMutation.isPending ? "Creating..." : "Create"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Workspace Cards */}
          {workspaces?.map((workspace) => (
            <Link
              key={workspace.id}
              href={`/workspace/${workspace.id}`}
              data-testid={`link-workspace-${workspace.id}`}
            >
              <Card className="hover-elevate cursor-pointer h-full">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2" data-testid={`text-workspace-name-${workspace.id}`}>
                    <Trello className="h-5 w-5 text-primary" />
                    {workspace.name}
                  </CardTitle>
                  {workspace.description && (
                    <CardDescription className="line-clamp-2" data-testid={`text-workspace-description-${workspace.id}`}>
                      {workspace.description}
                    </CardDescription>
                  )}
                  <div className="flex items-center gap-2 text-sm text-muted-foreground pt-2" data-testid={`text-workspace-members-${workspace.id}`}>
                    <Users className="h-4 w-4" />
                    <span>
                      {workspace.memberCount}{" "}
                      {workspace.memberCount === 1 ? "member" : "members"}
                    </span>
                  </div>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>

        {/* Empty State */}
        {workspaces && workspaces.length === 0 && (
          <div className="text-center py-12" data-testid="empty-state">
            <Trello className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-2xl font-semibold mb-2">No workspaces yet</h2>
            <p className="text-muted-foreground mb-6">
              Create your first workspace to get started
            </p>
            <Button onClick={() => setIsCreateOpen(true)} data-testid="button-create-first-workspace">
              <Plus className="h-4 w-4 mr-2" />
              Create Workspace
            </Button>
          </div>
        )}
      </main>
    </div>
  );
}
