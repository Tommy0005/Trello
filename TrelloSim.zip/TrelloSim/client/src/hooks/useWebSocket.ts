import { useEffect, useRef } from "react";
import { queryClient } from "@/lib/queryClient";

export function useWebSocket(boardId: string | undefined) {
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    if (!boardId) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log("WebSocket connected");
      ws.send(JSON.stringify({ type: "subscribe", boardId }));
    };

    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        console.log("WebSocket message:", message);

        // Invalidate queries on any board update
        if (
          message.type === "subscribed" ||
          message.type === "list:created" ||
          message.type === "list:updated" ||
          message.type === "list:deleted" ||
          message.type === "card:created" ||
          message.type === "card:updated" ||
          message.type === "card:deleted" ||
          message.type === "card:moved" ||
          message.type === "comment:new"
        ) {
          queryClient.invalidateQueries({ queryKey: ["/api/boards", boardId] });
        }
      } catch (error) {
        console.error("WebSocket message error:", error);
      }
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    ws.onclose = () => {
      console.log("WebSocket disconnected");
    };

    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    };
  }, [boardId]);

  return wsRef;
}
