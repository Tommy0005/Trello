import { create } from "zustand";

interface UIStore {
  // Card modal state
  openCardId: string | null;
  openCard: (cardId: string) => void;
  closeCard: () => void;

  // Board filters
  filters: {
    search: string;
    memberIds: string[];
    labelIds: string[];
    dueDate?: "overdue" | "today" | "week";
  };
  setSearch: (search: string) => void;
  toggleMemberFilter: (memberId: string) => void;
  toggleLabelFilter: (labelId: string) => void;
  setDueDateFilter: (filter?: "overdue" | "today" | "week") => void;
  clearFilters: () => void;

  // Drag state
  isDragging: boolean;
  setIsDragging: (isDragging: boolean) => void;

  // Label picker state
  isLabelPickerOpen: boolean;
  labelPickerCardId: string | null;
  openLabelPicker: (cardId: string) => void;
  closeLabelPicker: () => void;

  // Member selector state
  isMemberSelectorOpen: boolean;
  memberSelectorCardId: string | null;
  openMemberSelector: (cardId: string) => void;
  closeMemberSelector: () => void;
}

export const useUIStore = create<UIStore>((set) => ({
  // Card modal
  openCardId: null,
  openCard: (cardId) => set({ openCardId: cardId }),
  closeCard: () => set({ openCardId: null }),

  // Filters
  filters: {
    search: "",
    memberIds: [],
    labelIds: [],
  },
  setSearch: (search) =>
    set((state) => ({
      filters: { ...state.filters, search },
    })),
  toggleMemberFilter: (memberId) =>
    set((state) => ({
      filters: {
        ...state.filters,
        memberIds: state.filters.memberIds.includes(memberId)
          ? state.filters.memberIds.filter((id) => id !== memberId)
          : [...state.filters.memberIds, memberId],
      },
    })),
  toggleLabelFilter: (labelId) =>
    set((state) => ({
      filters: {
        ...state.filters,
        labelIds: state.filters.labelIds.includes(labelId)
          ? state.filters.labelIds.filter((id) => id !== labelId)
          : [...state.filters.labelIds, labelId],
      },
    })),
  setDueDateFilter: (filter) =>
    set((state) => ({
      filters: { ...state.filters, dueDate: filter },
    })),
  clearFilters: () =>
    set({
      filters: {
        search: "",
        memberIds: [],
        labelIds: [],
        dueDate: undefined,
      },
    }),

  // Drag state
  isDragging: false,
  setIsDragging: (isDragging) => set({ isDragging }),

  // Label picker
  isLabelPickerOpen: false,
  labelPickerCardId: null,
  openLabelPicker: (cardId) =>
    set({ isLabelPickerOpen: true, labelPickerCardId: cardId }),
  closeLabelPicker: () =>
    set({ isLabelPickerOpen: false, labelPickerCardId: null }),

  // Member selector
  isMemberSelectorOpen: false,
  memberSelectorCardId: null,
  openMemberSelector: (cardId) =>
    set({ isMemberSelectorOpen: true, memberSelectorCardId: cardId }),
  closeMemberSelector: () =>
    set({ isMemberSelectorOpen: false, memberSelectorCardId: null }),
}));
