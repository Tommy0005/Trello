import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useSortable } from "@dnd-kit/sortable";
import { useDroppable } from "@dnd-kit/core";
import { CSS } from "@dnd-kit/utilities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { GripVertical, Plus, MoreHorizontal, Trash2, X } from "lucide-react";
import { Card } from "@/components/Card";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useUIStore } from "@/stores/uiStore";
import type { ListWithCards } from "@shared/schema";

interface ListProps {
  list: ListWithCards;
}

export function List({ list }: ListProps) {
  const { toast } = useToast();
  const { openCard } = useUIStore();
  const [isEditing, setIsEditing] = useState(false);
  const [listName, setListName] = useState(list.name);
  const [isAddingCard, setIsAddingCard] = useState(false);
  const [newCardTitle, setNewCardTitle] = useState("");

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: list.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const updateListMutation = useMutation({
    mutationFn: async (newName: string) => {
      return await apiRequest("PATCH", `/api/lists/${list.id}`, {
        name: newName,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/boards"] });
      setIsEditing(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update list name.",
        variant: "destructive",
      });
      setListName(list.name);
    },
  });

  const deleteListMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("DELETE", `/api/lists/${list.id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/boards"] });
      toast({
        title: "List deleted",
        description: "The list has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete list.",
        variant: "destructive",
      });
    },
  });

  const createCardMutation = useMutation({
    mutationFn: async () => {
      const maxOrder =
        list.cards.length > 0
          ? Math.max(...list.cards.map((c) => c.orderingIndex))
          : 0;
      return await apiRequest("POST", "/api/cards", {
        listId: list.id,
        title: newCardTitle,
        orderingIndex: maxOrder + 1,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/boards"] });
      setNewCardTitle("");
      setIsAddingCard(false);
      toast({
        title: "Card created",
        description: "New card added to the list.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create card. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSaveName = () => {
    if (listName.trim() && listName !== list.name) {
      updateListMutation.mutate(listName.trim());
    } else {
      setIsEditing(false);
      setListName(list.name);
    }
  };

  const handleCreateCard = () => {
    if (newCardTitle.trim()) {
      createCardMutation.mutate();
    }
  };

  const sortedCards = [...list.cards].sort(
    (a, b) => a.orderingIndex - b.orderingIndex
  );

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="flex-shrink-0 w-[272px] flex flex-col max-h-full"
      data-testid={`list-${list.id}`}
    >
      <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-sm flex flex-col max-h-full">
        {/* List Header */}
        <div className="p-3 flex items-center gap-2 flex-shrink-0">
          <button
            {...attributes}
            {...listeners}
            className="cursor-grab active:cursor-grabbing text-muted-foreground hover:text-foreground p-1 -ml-1"
            data-testid={`drag-handle-list-${list.id}`}
          >
            <GripVertical className="h-4 w-4" />
          </button>

          {isEditing ? (
            <Input
              value={listName}
              onChange={(e) => setListName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleSaveName();
                } else if (e.key === "Escape") {
                  setIsEditing(false);
                  setListName(list.name);
                }
              }}
              onBlur={handleSaveName}
              autoFocus
              className="h-8 px-2 text-sm font-semibold flex-1"
              data-testid={`input-list-name-${list.id}`}
            />
          ) : (
            <h3
              onClick={() => setIsEditing(true)}
              className="flex-1 font-semibold text-sm cursor-pointer hover:bg-muted/50 px-2 py-1 rounded"
              data-testid={`text-list-name-${list.id}`}
            >
              {list.name}
            </h3>
          )}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 flex-shrink-0"
                data-testid={`button-list-menu-${list.id}`}
              >
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onClick={() => deleteListMutation.mutate()}
                className="text-destructive"
                data-testid={`button-delete-list-${list.id}`}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete List
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Cards Container */}
        <div className="flex-1 overflow-y-auto px-3 pb-2 space-y-2 min-h-0">
          <SortableContext
            items={sortedCards.map((c) => c.id)}
            strategy={verticalListSortingStrategy}
          >
            {sortedCards.map((card) => (
              <Card
                key={card.id}
                card={card}
                onClick={() => openCard(card.id)}
              />
            ))}
          </SortableContext>

          {/* Add Card Form */}
          {isAddingCard && (
            <div className="space-y-2">
              <Input
                placeholder="Enter card title..."
                value={newCardTitle}
                onChange={(e) => setNewCardTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleCreateCard();
                  } else if (e.key === "Escape") {
                    setIsAddingCard(false);
                    setNewCardTitle("");
                  }
                }}
                autoFocus
                className="text-sm"
                data-testid={`input-card-title-${list.id}`}
              />
              <div className="flex gap-2">
                <Button
                  onClick={handleCreateCard}
                  disabled={!newCardTitle.trim() || createCardMutation.isPending}
                  size="sm"
                  data-testid={`button-add-card-submit-${list.id}`}
                >
                  Add Card
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setIsAddingCard(false);
                    setNewCardTitle("");
                  }}
                  className="h-8 w-8"
                  data-testid={`button-add-card-cancel-${list.id}`}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Add Card Button */}
        {!isAddingCard && (
          <div className="p-2 flex-shrink-0">
            <Button
              variant="ghost"
              size="sm"
              className="w-full justify-start text-muted-foreground hover:text-foreground hover:bg-muted/50"
              onClick={() => setIsAddingCard(true)}
              data-testid={`button-add-card-${list.id}`}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add Card
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
