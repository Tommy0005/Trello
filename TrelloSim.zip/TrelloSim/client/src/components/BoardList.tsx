import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, X } from "lucide-react";
import { List } from "@/components/List";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  DndContext,
  DragOverlay,
  closestCorners,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import { SortableContext, horizontalListSortingStrategy } from "@dnd-kit/sortable";
import { useUIStore } from "@/stores/uiStore";
import type { ListWithCards } from "@shared/schema";
import { Card as CardComponent } from "@/components/Card";

interface BoardListProps {
  boardId: string;
  lists: ListWithCards[];
}

export function BoardList({ boardId, lists }: BoardListProps) {
  const { toast } = useToast();
  const { setIsDragging } = useUIStore();
  const [isAddingList, setIsAddingList] = useState(false);
  const [newListName, setNewListName] = useState("");
  const [activeId, setActiveId] = useState<string | null>(null);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor)
  );

  const createListMutation = useMutation({
    mutationFn: async () => {
      const maxOrder =
        lists.length > 0
          ? Math.max(...lists.map((l) => l.orderingIndex))
          : 0;
      return await apiRequest("POST", "/api/lists", {
        boardId,
        name: newListName,
        orderingIndex: maxOrder + 1,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/boards", boardId] });
      setNewListName("");
      setIsAddingList(false);
      toast({
        title: "List created",
        description: "New list added to the board.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create list. Please try again.",
        variant: "destructive",
      });
    },
  });

  const moveCardMutation = useMutation({
    mutationFn: async ({
      cardId,
      newListId,
      newOrderingIndex,
    }: {
      cardId: string;
      newListId: string;
      newOrderingIndex: number;
    }) => {
      return await apiRequest("POST", `/api/cards/${cardId}/move`, {
        listId: newListId,
        orderingIndex: newOrderingIndex,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/boards", boardId] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to move card. Please try again.",
        variant: "destructive",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/boards", boardId] });
    },
  });

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string);
    setIsDragging(true);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveId(null);
    setIsDragging(false);

    const { active, over } = event;
    if (!over || active.id === over.id) return;

    const activeCardId = active.id as string;
    const overContainerId = over.id as string;

    // Find the card being dragged
    let sourceList: ListWithCards | undefined;
    let draggedCard;
    for (const list of lists) {
      draggedCard = list.cards.find((c) => c.id === activeCardId);
      if (draggedCard) {
        sourceList = list;
        break;
      }
    }

    if (!draggedCard || !sourceList) return;

    // Determine if dropping on a card or a list
    let targetList = lists.find((l) => l.id === overContainerId);
    let newOrderingIndex: number;

    if (targetList) {
      // Dropped on an empty list or list header
      const cards = targetList.cards.filter((c) => c.id !== activeCardId);
      newOrderingIndex = cards.length > 0 ? cards[cards.length - 1].orderingIndex + 1 : 1;
    } else {
      // Dropped on a card - find which list it's in
      for (const list of lists) {
        const overCard = list.cards.find((c) => c.id === overContainerId);
        if (overCard) {
          targetList = list;
          // Calculate new position based on cards in target list
          const cards = list.cards
            .filter((c) => c.id !== activeCardId)
            .sort((a, b) => a.orderingIndex - b.orderingIndex);
          const overIndex = cards.findIndex((c) => c.id === overContainerId);
          
          if (overIndex === -1) {
            newOrderingIndex = 1;
          } else if (overIndex === 0) {
            newOrderingIndex = cards[0].orderingIndex / 2;
          } else {
            const prevCard = cards[overIndex - 1];
            const nextCard = cards[overIndex];
            newOrderingIndex = (prevCard.orderingIndex + nextCard.orderingIndex) / 2;
          }
          break;
        }
      }
    }

    if (targetList && newOrderingIndex !== undefined) {
      moveCardMutation.mutate({
        cardId: activeCardId,
        newListId: targetList.id,
        newOrderingIndex,
      });
    }
  };

  const handleCreateList = () => {
    if (newListName.trim()) {
      createListMutation.mutate();
    }
  };

  // Find the card being dragged for the overlay
  const activeCard = activeId
    ? lists
        .flatMap((list) => list.cards)
        .find((card) => card.id === activeId)
    : null;

  const sortedLists = [...lists].sort(
    (a, b) => a.orderingIndex - b.orderingIndex
  );

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCorners}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
    >
      <div
        className="h-full p-4 overflow-x-auto board-scroll"
        data-testid="board-lists-container"
      >
        <div className="flex gap-3 h-full">
          <SortableContext
            items={sortedLists.map((l) => l.id)}
            strategy={horizontalListSortingStrategy}
          >
            {sortedLists.map((list) => (
              <List key={list.id} list={list} />
            ))}
          </SortableContext>

          {/* Add List Button */}
          <div className="flex-shrink-0 w-[272px]" data-testid="add-list-container">
            {isAddingList ? (
              <div className="bg-black/20 backdrop-blur-sm rounded-lg p-3">
                <Input
                  placeholder="Enter list name..."
                  value={newListName}
                  onChange={(e) => setNewListName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleCreateList();
                    } else if (e.key === "Escape") {
                      setIsAddingList(false);
                      setNewListName("");
                    }
                  }}
                  autoFocus
                  className="mb-2 bg-white text-foreground"
                  data-testid="input-list-name"
                />
                <div className="flex gap-2">
                  <Button
                    onClick={handleCreateList}
                    disabled={!newListName.trim() || createListMutation.isPending}
                    size="sm"
                    data-testid="button-add-list-submit"
                  >
                    Add List
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      setIsAddingList(false);
                      setNewListName("");
                    }}
                    className="text-white hover:bg-white/20"
                    data-testid="button-add-list-cancel"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ) : (
              <Button
                variant="ghost"
                className="w-full justify-start text-white hover:bg-white/20"
                onClick={() => setIsAddingList(true)}
                data-testid="button-add-list"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add List
              </Button>
            )}
          </div>
        </div>
      </div>

      <DragOverlay>
        {activeCard ? (
          <div className="rotate-3 opacity-80">
            <CardComponent card={activeCard} onClick={() => {}} />
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}
