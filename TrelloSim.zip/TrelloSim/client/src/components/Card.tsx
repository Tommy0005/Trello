import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  CheckSquare,
  MessageSquare,
  Paperclip,
  Clock,
  AlertCircle,
} from "lucide-react";
import { format, isPast, isToday, isWithinInterval, addDays } from "date-fns";
import type { CardWithDetails } from "@shared/schema";

interface CardProps {
  card: CardWithDetails;
  onClick: () => void;
}

export function Card({ card, onClick }: CardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: card.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  // Calculate checklist progress
  const checklistStats = card.checklists.reduce(
    (acc, checklist) => {
      const total = checklist.items.length;
      const completed = checklist.items.filter((item) => item.completed).length;
      return {
        total: acc.total + total,
        completed: acc.completed + completed,
      };
    },
    { total: 0, completed: 0 }
  );

  const hasChecklists = checklistStats.total > 0;
  const checklistComplete =
    hasChecklists && checklistStats.completed === checklistStats.total;

  // Due date status
  let dueDateColor = "text-muted-foreground";
  let dueDateBg = "bg-muted";
  if (card.dueDate) {
    const dueDate = new Date(card.dueDate);
    if (isPast(dueDate) && !isToday(dueDate)) {
      dueDateColor = "text-destructive-foreground";
      dueDateBg = "bg-destructive";
    } else if (
      isToday(dueDate) ||
      isWithinInterval(dueDate, { start: new Date(), end: addDays(new Date(), 1) })
    ) {
      dueDateColor = "text-orange-700";
      dueDateBg = "bg-orange-100";
    }
  }

  const commentCount = card.comments?.length || 0;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      onClick={onClick}
      className="bg-card rounded-lg shadow-sm border hover:shadow-md hover-elevate cursor-pointer p-3 space-y-2 transition-shadow"
      data-testid={`card-${card.id}`}
    >
      {/* Cover Image */}
      {card.coverImageUrl && (
        <img
          src={card.coverImageUrl}
          alt=""
          className="w-full h-32 object-cover rounded -mx-3 -mt-3 mb-2"
          data-testid={`img-card-cover-${card.id}`}
        />
      )}

      {/* Labels */}
      {card.labels && card.labels.length > 0 && (
        <div className="flex flex-wrap gap-1" data-testid={`labels-${card.id}`}>
          {card.labels.slice(0, 4).map((cardLabel) => (
            <div
              key={cardLabel.label.id}
              className="h-2 w-10 rounded-full"
              style={{ backgroundColor: cardLabel.label.color }}
              title={cardLabel.label.name}
              data-testid={`label-${cardLabel.label.id}`}
            />
          ))}
          {card.labels.length > 4 && (
            <Badge variant="secondary" className="h-5 text-xs px-1.5">
              +{card.labels.length - 4}
            </Badge>
          )}
        </div>
      )}

      {/* Title */}
      <h4 className="text-sm font-medium leading-snug line-clamp-3" data-testid={`text-card-title-${card.id}`}>
        {card.title}
      </h4>

      {/* Badges */}
      <div className="flex flex-wrap gap-2 items-center text-xs text-muted-foreground">
        {/* Due Date */}
        {card.dueDate && (
          <div
            className={`flex items-center gap-1 px-2 py-0.5 rounded ${dueDateBg} ${dueDateColor}`}
            data-testid={`badge-due-date-${card.id}`}
          >
            {isPast(new Date(card.dueDate)) && !isToday(new Date(card.dueDate)) && (
              <AlertCircle className="h-3 w-3" />
            )}
            <Clock className="h-3 w-3" />
            <span className="font-medium">
              {format(new Date(card.dueDate), "MMM d")}
            </span>
          </div>
        )}

        {/* Checklist */}
        {hasChecklists && (
          <div
            className={`flex items-center gap-1 ${
              checklistComplete
                ? "text-green-600 bg-green-50"
                : "text-muted-foreground"
            } px-2 py-0.5 rounded`}
            data-testid={`badge-checklist-${card.id}`}
          >
            <CheckSquare className="h-3 w-3" />
            <span className="font-medium">
              {checklistStats.completed}/{checklistStats.total}
            </span>
          </div>
        )}

        {/* Comments */}
        {commentCount > 0 && (
          <div className="flex items-center gap-1" data-testid={`badge-comments-${card.id}`}>
            <MessageSquare className="h-3 w-3" />
            <span className="font-medium">{commentCount}</span>
          </div>
        )}

        {/* Attachments - placeholder for future */}
        {card.coverImageUrl && (
          <div className="flex items-center gap-1" data-testid={`badge-attachments-${card.id}`}>
            <Paperclip className="h-3 w-3" />
            <span className="font-medium">1</span>
          </div>
        )}

        {/* Members */}
        {card.members && card.members.length > 0 && (
          <div className="flex -space-x-2 ml-auto" data-testid={`members-${card.id}`}>
            {card.members.slice(0, 3).map((member) => (
              <Avatar
                key={member.user.id}
                className="h-6 w-6 border-2 border-card"
                data-testid={`avatar-member-${member.user.id}`}
              >
                <AvatarImage src={member.user.profileImageUrl || undefined} />
                <AvatarFallback className="text-xs bg-primary/10">
                  {member.user.firstName?.[0]}
                  {member.user.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
            ))}
            {card.members.length > 3 && (
              <Avatar className="h-6 w-6 border-2 border-card">
                <AvatarFallback className="text-xs bg-muted">
                  +{card.members.length - 3}
                </AvatarFallback>
              </Avatar>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
