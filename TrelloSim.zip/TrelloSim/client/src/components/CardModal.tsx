import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import {
  X,
  CreditCard,
  AlignLeft,
  CheckSquare,
  MessageSquare,
  Tag,
  Users,
  Calendar,
  Trash2,
  Plus,
} from "lucide-react";
import { format } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { CardWithDetails, User } from "@shared/schema";

interface CardModalProps {
  cardId: string;
  onClose: () => void;
}

export function CardModal({ cardId, onClose }: CardModalProps) {
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [isEditingDescription, setIsEditingDescription] = useState(false);
  const [commentText, setCommentText] = useState("");

  const { data: card, isLoading } = useQuery<CardWithDetails>({
    queryKey: ["/api/cards", cardId],
    enabled: !!cardId,
  });

  const { data: currentUser } = useQuery<User>({
    queryKey: ["/api/auth/user"],
  });

  useEffect(() => {
    if (card) {
      setTitle(card.title);
      setDescription(card.description || "");
    }
  }, [card]);

  const updateCardMutation = useMutation({
    mutationFn: async (data: { title?: string; description?: string }) => {
      return await apiRequest("PATCH", `/api/cards/${cardId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards", cardId] });
      queryClient.invalidateQueries({ queryKey: ["/api/boards"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update card.",
        variant: "destructive",
      });
    },
  });

  const addCommentMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/comments", {
        cardId,
        text: commentText,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards", cardId] });
      setCommentText("");
      toast({
        title: "Comment added",
        description: "Your comment has been posted.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add comment.",
        variant: "destructive",
      });
    },
  });

  const handleSaveTitle = () => {
    if (title.trim() && title !== card?.title) {
      updateCardMutation.mutate({ title: title.trim() });
    } else {
      setTitle(card?.title || "");
    }
  };

  const handleSaveDescription = () => {
    if (description !== card?.description) {
      updateCardMutation.mutate({ description });
    }
    setIsEditingDescription(false);
  };

  const handleAddComment = () => {
    if (commentText.trim()) {
      addCommentMutation.mutate();
    }
  };

  if (isLoading || !card) {
    return (
      <Dialog open onOpenChange={onClose}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden p-0">
          <div className="p-6">
            <p>Loading...</p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  const checklistStats = card.checklists.reduce(
    (acc, checklist) => {
      const total = checklist.items.length;
      const completed = checklist.items.filter((item) => item.completed).length;
      return {
        total: acc.total + total,
        completed: acc.completed + completed,
      };
    },
    { total: 0, completed: 0 }
  );

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent
        className="max-w-3xl max-h-[90vh] overflow-hidden p-0"
        data-testid="card-modal"
      >
        <div className="flex flex-col h-full max-h-[90vh]">
          {/* Header */}
          <DialogHeader className="p-6 pb-4 space-y-0 flex-shrink-0">
            <div className="flex items-start gap-3">
              <CreditCard className="h-5 w-5 text-muted-foreground mt-1 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  onBlur={handleSaveTitle}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.currentTarget.blur();
                    }
                  }}
                  className="text-xl font-semibold border-0 px-0 focus-visible:ring-0 focus-visible:ring-offset-0 -ml-1"
                  data-testid="input-card-title"
                />
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                data-testid="button-close-modal"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-6 pb-6 min-h-0">
            <div className="flex gap-4">
              {/* Main Content */}
              <div className="flex-1 space-y-6">
                {/* Labels */}
                {card.labels && card.labels.length > 0 && (
                  <div data-testid="section-labels">
                    <div className="flex items-center gap-2 mb-2">
                      <Tag className="h-4 w-4 text-muted-foreground" />
                      <h3 className="text-sm font-semibold">Labels</h3>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {card.labels.map((cardLabel) => (
                        <Badge
                          key={cardLabel.label.id}
                          style={{
                            backgroundColor: cardLabel.label.color,
                            color: "white",
                          }}
                          className="px-3 py-1"
                          data-testid={`label-badge-${cardLabel.label.id}`}
                        >
                          {cardLabel.label.name}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Members */}
                {card.members && card.members.length > 0 && (
                  <div data-testid="section-members">
                    <div className="flex items-center gap-2 mb-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <h3 className="text-sm font-semibold">Members</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {card.members.map((member) => (
                        <div
                          key={member.user.id}
                          className="flex items-center gap-2"
                          data-testid={`member-${member.user.id}`}
                        >
                          <Avatar className="h-8 w-8">
                            <AvatarImage
                              src={member.user.profileImageUrl || undefined}
                            />
                            <AvatarFallback className="text-xs">
                              {member.user.firstName?.[0]}
                              {member.user.lastName?.[0]}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-sm">
                            {member.user.firstName} {member.user.lastName}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Due Date */}
                {card.dueDate && (
                  <div data-testid="section-due-date">
                    <div className="flex items-center gap-2 mb-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <h3 className="text-sm font-semibold">Due Date</h3>
                    </div>
                    <p className="text-sm">
                      {format(new Date(card.dueDate), "MMMM d, yyyy")}
                    </p>
                  </div>
                )}

                {/* Description */}
                <div data-testid="section-description">
                  <div className="flex items-center gap-2 mb-2">
                    <AlignLeft className="h-4 w-4 text-muted-foreground" />
                    <h3 className="text-sm font-semibold">Description</h3>
                  </div>
                  {isEditingDescription ? (
                    <div className="space-y-2">
                      <Textarea
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="Add a more detailed description..."
                        className="min-h-24"
                        autoFocus
                        data-testid="textarea-description"
                      />
                      <div className="flex gap-2">
                        <Button
                          onClick={handleSaveDescription}
                          size="sm"
                          data-testid="button-save-description"
                        >
                          Save
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setDescription(card.description || "");
                            setIsEditingDescription(false);
                          }}
                          data-testid="button-cancel-description"
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div
                      onClick={() => setIsEditingDescription(true)}
                      className={`cursor-pointer rounded p-2 hover:bg-muted ${
                        description
                          ? "text-sm whitespace-pre-wrap"
                          : "text-sm text-muted-foreground"
                      }`}
                      data-testid="text-description"
                    >
                      {description || "Add a more detailed description..."}
                    </div>
                  )}
                </div>

                {/* Checklists */}
                {card.checklists.map((checklist) => (
                  <div key={checklist.id} data-testid={`checklist-${checklist.id}`}>
                    <div className="flex items-center gap-2 mb-2">
                      <CheckSquare className="h-4 w-4 text-muted-foreground" />
                      <h3 className="text-sm font-semibold">{checklist.title}</h3>
                    </div>
                    <div className="space-y-1">
                      {checklist.items
                        .sort((a, b) => a.orderingIndex - b.orderingIndex)
                        .map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center gap-2 p-2 hover:bg-muted rounded"
                            data-testid={`checklist-item-${item.id}`}
                          >
                            <Checkbox
                              checked={item.completed}
                              className="flex-shrink-0"
                              data-testid={`checkbox-item-${item.id}`}
                            />
                            <span
                              className={`text-sm ${
                                item.completed
                                  ? "line-through text-muted-foreground"
                                  : ""
                              }`}
                            >
                              {item.title}
                            </span>
                          </div>
                        ))}
                    </div>
                  </div>
                ))}

                {/* Activity / Comments */}
                <div data-testid="section-activity">
                  <div className="flex items-center gap-2 mb-3">
                    <MessageSquare className="h-4 w-4 text-muted-foreground" />
                    <h3 className="text-sm font-semibold">Activity</h3>
                  </div>

                  {/* Add Comment */}
                  <div className="flex gap-2 mb-4">
                    <Avatar className="h-8 w-8 flex-shrink-0">
                      <AvatarImage
                        src={currentUser?.profileImageUrl || undefined}
                      />
                      <AvatarFallback className="text-xs">
                        {currentUser?.firstName?.[0]}
                        {currentUser?.lastName?.[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 space-y-2">
                      <Textarea
                        placeholder="Write a comment..."
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        className="min-h-16"
                        data-testid="textarea-comment"
                      />
                      {commentText && (
                        <Button
                          onClick={handleAddComment}
                          disabled={addCommentMutation.isPending}
                          size="sm"
                          data-testid="button-add-comment"
                        >
                          {addCommentMutation.isPending ? "Posting..." : "Post"}
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Comments List */}
                  <div className="space-y-3">
                    {card.comments
                      ?.sort(
                        (a, b) =>
                          new Date(b.createdAt!).getTime() -
                          new Date(a.createdAt!).getTime()
                      )
                      .map((comment) => (
                        <div key={comment.id} className="flex gap-2" data-testid={`comment-${comment.id}`}>
                          <Avatar className="h-8 w-8 flex-shrink-0">
                            <AvatarImage
                              src={comment.user.profileImageUrl || undefined}
                            />
                            <AvatarFallback className="text-xs">
                              {comment.user.firstName?.[0]}
                              {comment.user.lastName?.[0]}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-semibold" data-testid={`comment-author-${comment.id}`}>
                                {comment.user.firstName} {comment.user.lastName}
                              </span>
                              <span className="text-xs text-muted-foreground" data-testid={`comment-date-${comment.id}`}>
                                {format(
                                  new Date(comment.createdAt!),
                                  "MMM d 'at' h:mm a"
                                )}
                              </span>
                            </div>
                            <div className="text-sm bg-muted p-2 rounded" data-testid={`comment-text-${comment.id}`}>
                              {comment.text}
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              </div>

              {/* Sidebar */}
              <div className="w-48 flex-shrink-0 space-y-2" data-testid="card-modal-sidebar">
                <div className="text-xs font-semibold text-muted-foreground mb-2">
                  ADD TO CARD
                </div>
                <Button variant="secondary" size="sm" className="w-full justify-start" data-testid="button-add-members">
                  <Users className="h-4 w-4 mr-2" />
                  Members
                </Button>
                <Button variant="secondary" size="sm" className="w-full justify-start" data-testid="button-add-labels">
                  <Tag className="h-4 w-4 mr-2" />
                  Labels
                </Button>
                <Button variant="secondary" size="sm" className="w-full justify-start" data-testid="button-add-checklist">
                  <CheckSquare className="h-4 w-4 mr-2" />
                  Checklist
                </Button>
                <Button variant="secondary" size="sm" className="w-full justify-start" data-testid="button-add-due-date">
                  <Calendar className="h-4 w-4 mr-2" />
                  Due Date
                </Button>

                <Separator className="my-2" />

                <div className="text-xs font-semibold text-muted-foreground mb-2">
                  ACTIONS
                </div>
                <Button
                  variant="destructive"
                  size="sm"
                  className="w-full justify-start"
                  data-testid="button-delete-card"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
